"""
algorithmic_analysis.py

  ['Jaya + DMN', 'CSO + DMN', 'HLBO + DMN', 'DTBO + DMN', 'Proposed HDTBO + DMN']
"""

import os
import config
import train_utils
from plot_utils import multi_panel_metric_figure

METRICS = ["attack_detection_rate", "f1_score", "fpr", "precision", "accuracy", "mcc"]

LEGEND_TO_OPTIMIZER = {
    "Jaya + DMN": "Jaya",
    "CSO + DMN": "CSO",
    "HLBO + DMN": "HLBO",
    "DTBO + DMN": "DTBO",
    "Proposed HDTBO + DMN": "HDTBO",
}


def run_algorithmic_analysis(train_pct: int = 90):
    results = {legend: {m: [] for m in METRICS} for legend in config.ALGORITHM_LEGEND}

    for solution_size in config.SOLUTION_SIZES:
        for legend in config.ALGORITHM_LEGEND:
            optimizer_name = LEGEND_TO_OPTIMIZER[legend]
            print(f"[algorithmic_analysis] solution_size={solution_size}, optimizer={optimizer_name}")
            res = train_utils.run_pipeline(
                train_pct=train_pct, optimizer_name=optimizer_name,
                max_iterations=config.MAX_ITERATIONS, pop_size=solution_size,
            )
            for m in METRICS:
                results[legend][m].append(res[m])

    save_path = os.path.join(config.OUTPUT_DIR, "figure11_algorithmic_analysis.png")
    multi_panel_metric_figure(
        x_labels=[str(s) for s in config.SOLUTION_SIZES],
        results=results, metrics=METRICS,
        suptitle="Figure 11. Algorithmic evaluation\n"
                  "(varying solution size, legend = optimizer + DMN)",
        save_path=save_path, xlabel="Solution size",
    )
    return results


if __name__ == "__main__":
    run_algorithmic_analysis()
