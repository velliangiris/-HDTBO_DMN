"""
performance_analysis.py
========================
Performance analysis of the proposed HDTBO_DMN, Section 5.4 (Figure 7)
and Section 5.6.2 (Figure 9, restricted to the proposed model since
comparative baselines were explicitly excluded from this rebuild):

  (a) Metrics vs Training Percentage (x-axis), one line/bar-group per
      iteration count (legend) -- exactly Figure 7's layout.
  (b) Metrics vs K-fold value (x-axis), one bar-group per iteration
      count (legend) -- Figure 9's x-axis, restricted to the proposed
      model only.

Both produce a 6-panel figure: Attack detection rate, F1-score, FPR,
Precision, Accuracy, MCC.
"""

import os
import config
import train_utils
from plot_utils import multi_panel_metric_figure

METRICS = ["attack_detection_rate", "f1_score", "fpr", "precision", "accuracy", "mcc"]


def run_training_percentage_sweep():
    """Figure 7 style: x-axis = training %, legend = iterations."""
    results = {f"Iteration = {it}": {m: [] for m in METRICS} for it in config.ITERATION_LEGEND}

    for train_pct in config.TRAINING_PERCENTAGES:
        for it in config.ITERATION_LEGEND:
            print(f"[performance_analysis] train%={train_pct}, iterations={it}")
            res = train_utils.run_pipeline(
                train_pct=train_pct, optimizer_name="HDTBO",
                max_iterations=it, pop_size=config.POP_SIZE,
            )
            for m in METRICS:
                results[f"Iteration = {it}"][m].append(res[m])

    save_path = os.path.join(config.OUTPUT_DIR, "figure7_performance_vs_training_pct.png")
    multi_panel_metric_figure(
        x_labels=[f"{p}%" for p in config.TRAINING_PERCENTAGES],
        results=results, metrics=METRICS,
        suptitle="Figure 7. Performance analysis of Proposed HDTBO_DMN\n"
                  "(varying training percentage, legend = iterations)",
        save_path=save_path, xlabel="Training data percentage",
    )
    return results


def run_kfold_sweep():
    """Figure 9 style: x-axis = K-fold value, legend = iterations (proposed only)."""
    results = {f"Iteration = {it}": {m: [] for m in METRICS} for it in config.ITERATION_LEGEND}

    for k in config.KFOLD_VALUES:
        for it in config.ITERATION_LEGEND:
            print(f"[performance_analysis] K-fold={k}, iterations={it}")
            res = train_utils.run_pipeline_kfold(
                k=k, optimizer_name="HDTBO", max_iterations=it, pop_size=config.POP_SIZE,
            )
            for m in METRICS:
                results[f"Iteration = {it}"][m].append(res[m])

    save_path = os.path.join(config.OUTPUT_DIR, "figure9_performance_vs_kfold.png")
    multi_panel_metric_figure(
        x_labels=[str(k) for k in config.KFOLD_VALUES],
        results=results, metrics=METRICS,
        suptitle="Figure 9. Performance analysis of Proposed HDTBO_DMN\n"
                  "(varying K-fold, legend = iterations)",
        save_path=save_path, xlabel="K-fold value",
    )
    return results


if __name__ == "__main__":
    run_training_percentage_sweep()
    run_kfold_sweep()
