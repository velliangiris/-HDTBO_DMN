"""
auth_phase.py
=============
Implements the **Authentication Phase** from Figure 2 (Section 4.1 of the
manuscript), which was previously missing from this codebase -- everything
here sits *before/alongside* the Communication & Intrusion-Detection phase
(data_utils / feature_fusion / dmn_model / optimizers.HDTBO).

Figure 2 top row, implemented end to end below:

    Initialization -> Registration -> Key Generation -> Login ->
    Authentication -> Data Protection (RHHO key) -> Authorization ->
    Data Sharing & Access Control -> [Data decryption, Section 4.1.8]

Entities (Figure 2 / Figure 3): User, IoT Server, Blockchain + Authenticating
Miners, Owner.

Primitives used to realize the manuscript's notation (Table 2) concretely:
    h(.)        SHA-256 hash                              (hbar, "ℏ")
    xor(a, b)   byte-wise XOR                               (⊕)
    a || b      string/byte concatenation                   (||)
    mod_range   value folded into config.AUTH_RANDOM_RANGE  ("mod [0,2]")

Equation map (manuscript Section 4.1, embedded as image/OLE objects and
transcribed here from the rendered equations):
    Eq.1  X1  = K_pu XOR h(O_id || m)                 (owner registration)
    Eq.2  X2  = h(U_pwd*** || m) XOR h(U_id*** || n)   (user registration)
    Eq.3  K_pr = h(U_id*** XOR v) XOR h(U_pwd***) XOR K_pu   (key generation)
    Eq.4  L_id = h(K_pr || v) XOR h(U_pwd) || mod(n)   (login ID)
    Eq.5  X3  = h(U_id*** XOR mod(m))
    Eq.6  X4  = h(U_pwd*** XOR mod(v))
    Eq.7  CP(z) = 32z^6 + 14z^4 + 2z^2 + 16            (Chebyshev polynomial)
    Eq.8-9  Gamma(f, l) = |f ∩ l| / min(|f|, |l|)      (overlap coefficient)
    Eq.10 A = E(chi, tau)                              (encryption)
    Eq.11 RHHO position update                          (see optimizers.RHHO)
    Eq.12 A_q  = h(m || K_pr || mod(u)) XOR h(U_pwd || mod(n))  (auth request)
    Eq.13 A_q~ = same, recomputed at the IoT server
    Eq.14 OTP  = h(U_id*** || K_pu) XOR mod(v)
    Eq.15 X    = h(U_id || v) XOR (m || n)             (access request)
    Eq.16 Y_pwd = h(U_pwd XOR K_pu) || (v XOR n)        (session password)
    Eq.17 X~   = h(Y_pwd* || K_pu) || (T XOR v)         (blockchain message)
    Eq.18 X~   = h(U_pwd*** || n)                       (post-timestamp check)
    Eq.19 J    = D(d**, K)                              (decryption)
    Eq.20 D    = J / K                                  (symbolic inverse of E)

Honesty note: the exact byte-level definition of E()/D() (Eq. 10/19-20) is
not spelled out beyond "encryption"/"decryption of the key-protected data",
so E is realized here as a concrete, invertible RHHO-keyed stream cipher
(SHA-256-based keystream XORed with the Chebyshev/overlap-weighted data) --
functionally consistent with the manuscript's description, exactly
invertible by D, and documented so it can be swapped for another concrete
cipher if the venue requires one.
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

import config
from optimizers import RHHO


# ---------------------------------------------------------------------
# Primitives: h(.), XOR, concatenation, "mod [range]"
# ---------------------------------------------------------------------
def h(*parts) -> bytes:
    """SHA-256 hash (ℏ) over the concatenation (||) of its arguments."""
    hasher = hashlib.sha256()
    for p in parts:
        if isinstance(p, bytes):
            hasher.update(p)
        elif isinstance(p, str):
            hasher.update(p.encode("utf-8"))
        elif isinstance(p, float):
            hasher.update(np.float64(p).tobytes())
        else:
            hasher.update(str(p).encode("utf-8"))
        hasher.update(b"||")
    return hasher.digest()


def xor(a: bytes, b: bytes) -> bytes:
    """Byte-wise XOR (⊕); shorter operand is cycled to match length."""
    n = max(len(a), len(b))
    return bytes(a[i % len(a)] ^ b[i % len(b)] for i in range(n))


def rand_in_range(rng: np.random.Generator, lo=None, hi=None) -> float:
    lo = config.AUTH_RANDOM_RANGE[0] if lo is None else lo
    hi = config.AUTH_RANDOM_RANGE[1] if hi is None else hi
    return float(rng.uniform(lo, hi))


def mod_range(value, lo=None, hi=None) -> float:
    """'mod [0, 2]' -- fold a real value into the configured random-number range."""
    lo = config.AUTH_RANDOM_RANGE[0] if lo is None else lo
    hi = config.AUTH_RANDOM_RANGE[1] if hi is None else hi
    span = hi - lo
    return lo + (abs(value) % span) if span > 0 else lo


# ---------------------------------------------------------------------
# Entities (Figure 2 / Figure 3)
# ---------------------------------------------------------------------
@dataclass
class Owner:
    owner_id: str
    store: dict = field(default_factory=dict)


@dataclass
class User:
    user_id: str
    password: str
    store: dict = field(default_factory=dict)


@dataclass
class IoTServer:
    K_pu: bytes = field(default_factory=lambda: h("public-key-seed", time.time()))
    security_param: bytes = field(default_factory=lambda: h("security-param-seed"))
    registered_owners: dict = field(default_factory=dict)
    registered_users: dict = field(default_factory=dict)
    store: dict = field(default_factory=dict)


@dataclass
class Blockchain:
    ledger: list = field(default_factory=list)
    store: dict = field(default_factory=dict)


@dataclass
class PhaseResult:
    phase: str
    success: bool
    detail: str = ""


# ---------------------------------------------------------------------
# The full protocol, phase by phase
# ---------------------------------------------------------------------
class AuthenticationProtocol:
    """
    Orchestrates one full run of Figure 2's Authentication Phase for a
    single (owner, user) pair, exactly mirroring the eight sub-sections
    of Section 4.1. Every `_phase_*` method returns a `PhaseResult` and
    raises nothing -- callers (or `run()`) decide whether to abort on
    failure, matching "...else terminate the session" in Section 4.1.7.
    """

    def __init__(self, user_id: str, password: str, owner_id: str = "owner-01",
                 seed: Optional[int] = None):
        self.rng = np.random.default_rng(config.RANDOM_STATE if seed is None else seed)
        self.server = IoTServer()
        self.blockchain = Blockchain()
        self.owner = Owner(owner_id)
        self.user = User(user_id, password)
        self.results: list[PhaseResult] = []
        self.rhho_key: Optional[bytes] = None

    # -- 4.1.1 Initialization ------------------------------------------------
    def _phase_initialization(self) -> PhaseResult:
        # Only the IoT server acts here: initialize K_pu, security parameter,
        # random number r in [0, 2] mod [0, 2].
        self.server.K_pu = h("public-key-seed", time.time_ns())
        self.server.security_param = h("security-param-seed", time.time_ns())
        r = mod_range(rand_in_range(self.rng))
        self.server.store["r"] = r
        return PhaseResult("Initialization", True,
                            f"K_pu={self.server.K_pu[:4].hex()}..., r={r:.3f}")

    # -- 4.1.2 Registration ---------------------------------------------------
    def _phase_registration(self) -> PhaseResult:
        m = rand_in_range(self.rng)
        n = rand_in_range(self.rng)

        # (a) owner <-> IoT server (Eq. 1)
        X1_server = xor(self.server.K_pu, h(self.owner.owner_id, m))
        self.owner.store["X1**"] = X1_server          # owner's stored copy
        X1_owner_check = xor(self.server.K_pu, h(self.owner.owner_id, m))
        owner_ok = X1_owner_check == self.owner.store["X1**"]
        if owner_ok:
            self.server.registered_owners[self.owner.owner_id] = True

        # (b) user <-> IoT server (Eq. 2)
        U_id_star = h(self.user.user_id, "id-salt")     # U_id***
        U_pwd_star = h(self.user.password, "pwd-salt")  # U_pwd***
        self.user.store["U_id***"] = U_id_star
        self.user.store["U_pwd***"] = U_pwd_star
        self.server.store["m"], self.server.store["n"] = m, n

        X2_server = xor(h(U_pwd_star, m), h(U_id_star, n))
        X2_user = xor(h(U_pwd_star, m), h(U_id_star, n))  # user recomputes identically
        user_ok = X2_server == X2_user
        if user_ok:
            self.server.registered_users[self.user.user_id] = True
            self.user.store["X2**"] = X2_user

        success = owner_ok and user_ok
        return PhaseResult("Registration", success,
                            f"owner_verified={owner_ok}, user_verified={user_ok}")

    # -- 4.1.3 Key generation --------------------------------------------------
    def _phase_key_generation(self) -> PhaseResult:
        v = rand_in_range(self.rng)
        self.server.store["v"] = v
        U_id_star = self.user.store["U_id***"]
        U_pwd_star = self.user.store["U_pwd***"]

        # Eq. 3: K_pr = h(U_id*** XOR v) XOR h(U_pwd***) XOR K_pu
        K_pr = xor(xor(h(U_id_star, v), h(U_pwd_star)), self.server.K_pu)
        self.user.store["K_pr**"] = K_pr
        self.server.store["K_pr"] = K_pr
        return PhaseResult("Key Generation", True, f"K_pr={K_pr[:4].hex()}...")

    # -- 4.1.4 Login -------------------------------------------------------------
    def _phase_login(self) -> PhaseResult:
        v = self.server.store["v"]
        n = self.server.store["n"]
        m = self.server.store["m"]
        K_pr = self.user.store["K_pr**"]
        U_id_star = self.user.store["U_id***"]
        U_pwd_star = self.user.store["U_pwd***"]

        # Eq. 4: login ID
        L_id = xor(h(K_pr, v), h(self.user.password, mod_range(n)))
        # Eq. 5, 6: verification tokens
        X3 = h(U_id_star, mod_range(m))
        X4 = h(U_pwd_star, mod_range(v))

        X3_server = h(U_id_star, mod_range(m))
        X4_server = h(U_pwd_star, mod_range(v))
        success = (X3 == X3_server) and (X4 == X4_server)

        self.user.store["L_id"] = L_id
        self.server.store["L_id"] = L_id
        return PhaseResult("Login", success, f"L_id={L_id[:4].hex()}...")

    # -- 4.1.5 Data protection (Chebyshev + overlap coeff. + RHHO key) ---------
    @staticmethod
    def chebyshev_transform(z: np.ndarray) -> np.ndarray:
        """Eq. 7: CP(z) = 32 z^6 + 14 z^4 + 2 z^2 + 16."""
        z = np.asarray(z, dtype=np.float64)
        return 32 * z**6 + 14 * z**4 + 2 * z**2 + 16

    @staticmethod
    def overlap_coefficient(f: np.ndarray, l: np.ndarray) -> float:
        """Eq. 8-9: Gamma(f, l) = |f ∩ l| / min(|f|, |l|), on binarized supports."""
        f_set = set(np.flatnonzero(np.asarray(f) > np.median(f)))
        l_set = set(np.flatnonzero(np.asarray(l) > np.median(l)))
        if not f_set or not l_set:
            return 0.0
        inter = len(f_set & l_set)
        return inter / min(len(f_set), len(l_set))

    def _rhho_key_fitness(self, candidate: np.ndarray) -> float:
        """
        Objective RHHO minimizes when searching for the secret key: a
        higher-quality key should (a) look uniformly random -- maximize
        Shannon entropy of its derived bytes -- and (b) exhibit a strong
        avalanche effect (a tiny perturbation should flip roughly half the
        derived key bits). Both are standard, checkable proxies for "the
        key strengthens resilience against statistical and brute-force
        attacks" (Section 4.1.5). We return the *negative* of the combined
        score since optimizers here minimize.
        """
        key_bytes = self._vector_to_key(candidate)
        counts = np.bincount(np.frombuffer(key_bytes, dtype=np.uint8), minlength=256)
        p = counts[counts > 0] / counts.sum()
        entropy = -np.sum(p * np.log2(p))  # max 8.0 for AUTH_KEY_BYTES bytes

        perturbed = candidate.copy()
        perturbed[0] += 1e-3
        perturbed_bytes = self._vector_to_key(perturbed)
        bits_a = np.unpackbits(np.frombuffer(key_bytes, dtype=np.uint8))
        bits_b = np.unpackbits(np.frombuffer(perturbed_bytes, dtype=np.uint8))
        avalanche = np.mean(bits_a != bits_b)  # ideal ~0.5

        score = entropy / 8.0 + (1 - abs(avalanche - 0.5) * 2)
        return -score

    @staticmethod
    def _vector_to_key(vector: np.ndarray) -> bytes:
        digest = hashlib.sha256(np.asarray(vector, dtype=np.float64).tobytes()).digest()
        return digest[:config.AUTH_KEY_BYTES]

    def _phase_data_protection(self, log_data: np.ndarray) -> PhaseResult:
        # Chebyshev transform (Eq. 7) then overlap-coefficient feature scoring (Eq. 8-9)
        z = (log_data - log_data.min()) / (np.ptp(log_data) + 1e-9)
        cp = self.chebyshev_transform(z)
        labels = (log_data > np.median(log_data)).astype(float)
        overlap = self.overlap_coefficient(cp.mean(axis=1) if cp.ndim > 1 else cp,
                                            labels.mean(axis=1) if labels.ndim > 1 else labels)

        # RHHO (ROA + HOA hybrid, Eq. 11) searches for the secret key
        rhho = RHHO(seed=config.RANDOM_STATE)
        best_vec, best_fit, _curve = rhho.optimize(
            self._rhho_key_fitness,
            dim=config.AUTH_KEY_DIM,
            lower_bound=config.AUTH_KEY_LOWER_BOUND,
            upper_bound=config.AUTH_KEY_UPPER_BOUND,
            pop_size=config.AUTH_RHHO_POP_SIZE,
            max_iterations=config.AUTH_RHHO_MAX_ITERATIONS,
        )
        self.rhho_key = self._vector_to_key(best_vec)

        # Eq. 10: A = E(chi, tau) -- concrete realization: SHA-256 keystream
        # cipher keyed by the RHHO key, applied to the Chebyshev/overlap-
        # weighted data, invertible by _decrypt().
        weighted = cp * (0.5 + overlap)
        encrypted = self._encrypt(weighted, self.rhho_key)

        self.server.store["A"] = encrypted
        self.server.store["overlap_coeff"] = overlap
        self.user.store["K"] = self.rhho_key
        return PhaseResult(
            "Data Protection", True,
            f"RHHO key={self.rhho_key.hex()}, overlap={overlap:.3f}, "
            f"key_fitness={-best_fit:.3f}",
        )

    @staticmethod
    def _keystream(key: bytes, n_bytes: int) -> bytes:
        out = b""
        counter = 0
        while len(out) < n_bytes:
            out += hashlib.sha256(key + counter.to_bytes(4, "big")).digest()
            counter += 1
        return out[:n_bytes]

    def _encrypt(self, data: np.ndarray, key: bytes) -> dict:
        payload = data.astype(np.float64).tobytes()
        ks = self._keystream(key, len(payload))
        cipher = xor(payload, ks)
        return {"cipher": cipher, "shape": data.shape, "dtype": str(data.dtype)}

    def _decrypt(self, packet: dict, key: bytes) -> np.ndarray:
        """Eq. 19-20: J = D(d**, K); realized as the inverse of _encrypt()."""
        ks = self._keystream(key, len(packet["cipher"]))
        plain_bytes = xor(packet["cipher"], ks)
        return np.frombuffer(plain_bytes, dtype=packet["dtype"]).reshape(packet["shape"])

    # -- 4.1.6 Authentication (OTP) --------------------------------------------
    def _phase_authentication(self) -> PhaseResult:
        u = rand_in_range(self.rng)
        self.server.store["u"] = u
        K_pr = self.server.store["K_pr"]
        n = self.server.store["n"]

        # Eq. 12: user's authentication request
        A_q_user = xor(h(self.server.store["m"], K_pr, mod_range(u)),
                       h(self.user.password, mod_range(n)))
        # Eq. 13: recomputed / stored at the IoT server
        A_q_server = xor(h(self.server.store["m"], K_pr, mod_range(u)),
                          h(self.user.password, mod_range(n)))
        request_ok = A_q_user == A_q_server
        if not request_ok:
            return PhaseResult("Authentication", False, "authentication request mismatch")

        # Eq. 14: server issues an OTP
        U_id_star = self.user.store["U_id***"]
        v = self.server.store["v"]
        otp = xor(h(U_id_star, self.server.K_pu), mod_range(v).hex().encode())
        otp_short = hashlib.sha256(otp).hexdigest()[:6].upper()
        self.server.store["otp"] = otp
        self.server.store["otp_issued_at"] = time.time()

        # user recomputes the same OTP from shared material to "receive" it
        otp_user = xor(h(U_id_star, self.server.K_pu), mod_range(v).hex().encode())
        verified = otp_user == otp
        return PhaseResult("Authentication", verified, f"OTP={otp_short}, verified={verified}")

    # -- 4.1.7 Access control & Authorization (Figure 3) -----------------------
    def _phase_authorization(self) -> PhaseResult:
        v = self.server.store["v"]
        m = self.server.store["m"]
        n = self.server.store["n"]

        # Eq. 15: user -> auth miners -> IoT server, data access request
        X_user = xor(h(self.user.user_id, v), (str(m) + str(n)).encode())
        X_server = xor(h(self.user.user_id, v), (str(m) + str(n)).encode())
        request_ok = X_user == X_server
        if not request_ok:
            return PhaseResult("Authorization", False, "access request invalid; session terminated")

        # Eq. 16: server issues a session password
        Y_pwd = h(xor(h(self.user.password), self.server.K_pu), f"{v}{n}")
        self.blockchain.store["Y_pwd*"] = Y_pwd

        # Eq. 17: blockchain timestamps the session
        T = time.time()
        X_tilde = h(Y_pwd, self.server.K_pu, f"{T}{v}")
        self.blockchain.ledger.append({"X~": X_tilde, "T": T})

        # Timestamp validity check -> Eq. 18, else terminate session
        delay = time.time() - T
        timestamp_valid = delay <= config.AUTH_TIMESTAMP_MAX_DELAY
        if not timestamp_valid:
            return PhaseResult("Authorization", False, "stale timestamp; session terminated")

        X_tilde_2 = h(self.user.store["U_pwd***"], n)
        # Eq. valid check X~ == X~ (message accepted by the blockchain)
        message_valid = X_tilde_2 == h(self.user.store["U_pwd***"], n)

        if message_valid:
            # Blockchain releases the secured data to server (d*) and user (d**)
            d_star = self.server.store.get("A")
            d_star_star = d_star
            self.server.store["d*"] = d_star
            self.user.store["d**"] = d_star_star

        return PhaseResult(
            "Authorization", message_valid,
            f"session_password={Y_pwd[:4].hex()}..., timestamp_delay={delay*1000:.2f}ms",
        )

    # -- 4.1.8 Data decryption ---------------------------------------------------
    def _phase_decryption(self, original_log_data: np.ndarray) -> PhaseResult:
        packet = self.user.store.get("d**")
        key = self.user.store.get("K")
        if packet is None or key is None:
            return PhaseResult("Data Decryption", False, "no authorized packet to decrypt")

        recovered = self._decrypt(packet, key)  # Eq. 19: J = D(d**, K)
        # round-trip sanity check against what data_protection actually encrypted
        expected = self._encrypt(
            self.chebyshev_transform(
                (original_log_data - original_log_data.min())
                / (np.ptp(original_log_data) + 1e-9)
            )
            * (0.5 + self.server.store["overlap_coeff"]),
            key,
        )
        success = recovered.shape == packet["shape"] and packet["cipher"] == expected["cipher"]
        return PhaseResult("Data Decryption", success,
                            f"recovered array shape={recovered.shape}")

    # -- Orchestration -----------------------------------------------------------
    def run(self, log_data: np.ndarray, verbose: bool = True) -> list[PhaseResult]:
        """
        Runs all eight sub-phases in order, aborting early (and recording
        the failure) if any phase fails -- matching the manuscript's
        "...else terminate the session" behaviour.
        """
        self.results = []
        phases = [
            ("Initialization", lambda: self._phase_initialization()),
            ("Registration", lambda: self._phase_registration()),
            ("Key Generation", lambda: self._phase_key_generation()),
            ("Login", lambda: self._phase_login()),
            ("Authentication", lambda: self._phase_authentication()),
            ("Data Protection", lambda: self._phase_data_protection(log_data)),
            ("Authorization", lambda: self._phase_authorization()),
            ("Data Decryption", lambda: self._phase_decryption(log_data)),
        ]
        for name, fn in phases:
            result = fn()
            self.results.append(result)
            if verbose:
                status = "OK" if result.success else "FAIL"
                print(f"  [{status:4s}] {result.phase:<16s} {result.detail}")
            if not result.success:
                if verbose:
                    print(f"  -> session terminated at '{name}'")
                break
        return self.results


def run_authentication_protocol_demo(n_rows: int = 8, n_cols: int = 6,
                                      seed: Optional[int] = None) -> list[PhaseResult]:
    """
    End-to-end demo: one recorded-log-data batch flows through the full
    Authentication Phase (Figure 2 top row + Figure 3), from Initialization
    to Data Decryption, using a real (fast-mode) RHHO key search.
    """
    rng = np.random.default_rng(config.RANDOM_STATE if seed is None else seed)
    log_data = rng.normal(size=(n_rows, n_cols))

    protocol = AuthenticationProtocol(user_id="patient-monitor-07",
                                       password="s3cure-pass", seed=seed)
    print("Authentication Phase demo (Section 4.1 / Figure 2 top row, Figure 3)")
    results = protocol.run(log_data)
    all_ok = all(r.success for r in results) and len(results) == 8
    print(f"\nAll {len(results)}/8 phases passed: {all_ok}")
    return results


if __name__ == "__main__":
    run_authentication_protocol_demo()
