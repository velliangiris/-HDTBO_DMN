"""

"""

import numpy as np
from sklearn.model_selection import train_test_split, StratifiedKFold

import config
import data_utils
import metrics as metrics_mod
from dmn_model import build_dmn
from feature_fusion import LevenshteinDNNFusion
from optimizers import get_optimizer


def make_fitness_fn(dmn, X: np.ndarray, y: np.ndarray, sample_size: int = 512,
                     seed: int = 42):
    """
    Builds a fitness function f(weight_vector) -> scalar (lower is better)
    for the metaheuristic optimizers, per Eq. 39: the fitness measures the
    error between target output and the DMN's predicted result. A fixed
    random subsample keeps every fitness evaluation cheap while remaining
    deterministic within a single optimization run.
    """
    rng = np.random.default_rng(seed)
    n = len(X)
    if n > sample_size:
        idx = rng.choice(n, size=sample_size, replace=False)
        Xs, ys = X[idx], y[idx]
    else:
        Xs, ys = X, y

    def fitness(weight_vector: np.ndarray) -> float:
        proba = dmn.forward(Xs, weight_vector, training=False)
        pred = proba.argmax(axis=1)
        err = 1.0 - metrics_mod.accuracy(ys, pred)
        # small L2 regularization on the weight vector, mirroring Table 4's
        # "Weight decay (L2) = 1e-4"
        reg = config.DMN_WEIGHT_DECAY * np.mean(weight_vector ** 2)
        return err + reg

    return fitness


def train_dmn_with_optimizer(X_train, y_train, optimizer_name: str,
                              max_iterations: int, pop_size: int,
                              n_layers: int = None, hidden_units: int = None,
                              seed: int = None):
    """
    Trains a DeepMaxoutNetwork's weight vector using the named
    metaheuristic optimizer. Returns (dmn, best_weights, convergence_curve).
    """
    seed = config.RANDOM_STATE if seed is None else seed
    n_layers = n_layers or config.DMN_NUM_LAYERS
    hidden_units = hidden_units or config.DMN_HIDDEN_UNITS

    n_classes = len(np.unique(y_train))
    dmn = build_dmn(input_dim=X_train.shape[1], n_classes=n_classes,
                     n_layers=n_layers, hidden_units=hidden_units,
                     k_pieces=config.DMN_MAXOUT_PIECES,
                     dropout_rate=config.DMN_DROPOUT_RATE, seed=seed)

    fitness_fn = make_fitness_fn(dmn, X_train, y_train, seed=seed)

    optimizer = get_optimizer(optimizer_name, seed=seed)
    best_weights, best_fitness, curve = optimizer.optimize(
        fitness_fn=fitness_fn,
        dim=dmn.dim,
        lower_bound=config.LOWER_BOUND,
        upper_bound=config.UPPER_BOUND,
        pop_size=pop_size,
        max_iterations=max_iterations,
    )
    return dmn, best_weights, curve


def evaluate_dmn(dmn, weights, X_test, y_test) -> dict:
    proba = dmn.predict_proba(X_test, weights)
    pred = proba.argmax(axis=1)
    score = proba[:, 1] if proba.shape[1] > 1 else proba[:, 0]
    return metrics_mod.all_metrics(y_test, pred, y_score=score)


def prepare_data(train_pct: float = 80, apply_preprocessing: bool = True,
                  apply_augmentation: bool = True, apply_feature_fusion: bool = True,
                  seed: int = None):
    """
    Loads BoT-IoT (or synthetic fallback), applies the requested
    preprocessing / augmentation / feature-fusion stages, and splits into
    train/test using `train_pct` % for training (remainder for testing).
    """
    seed = config.RANDOM_STATE if seed is None else seed
    df = data_utils.load_dataset()

    if apply_preprocessing:
        df = data_utils.handle_missing_values(df)
        df, _ = data_utils.min_max_normalize(df)
    else:
        # still need a numeric matrix -> fill NaNs with 0, no scaling
        feature_cols = [c for c in df.columns if c != config.LABEL_COLUMN]
        df[feature_cols] = df[feature_cols].fillna(0.0)

    feature_cols = [c for c in df.columns if c != config.LABEL_COLUMN]
    X = df[feature_cols].values.astype(np.float64)
    y = df[config.LABEL_COLUMN].values.astype(int)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, train_size=train_pct / 100.0, random_state=seed, stratify=y
    )

    if apply_augmentation:
        X_train, y_train = data_utils.smote_augment(X_train, y_train, random_state=seed)

    if apply_feature_fusion:
        fusion = LevenshteinDNNFusion(random_state=seed)
        X_train = fusion.fit_transform(X_train, y_train)
        X_test = fusion.transform(X_test)

    return X_train, X_test, y_train, y_test


def run_pipeline(train_pct: float = 80, optimizer_name: str = "HDTBO",
                  max_iterations: int = None, pop_size: int = None,
                  apply_preprocessing: bool = True, apply_augmentation: bool = True,
                  apply_feature_fusion: bool = True, n_layers: int = None,
                  seed: int = None) -> dict:
    """
    End-to-end run: prepare data -> train DMN with chosen optimizer ->
    evaluate on held-out test split. Returns a metrics dict.
    """
    max_iterations = max_iterations or config.MAX_ITERATIONS
    pop_size = pop_size or config.POP_SIZE
    seed = config.RANDOM_STATE if seed is None else seed

    X_train, X_test, y_train, y_test = prepare_data(
        train_pct=train_pct, apply_preprocessing=apply_preprocessing,
        apply_augmentation=apply_augmentation,
        apply_feature_fusion=apply_feature_fusion, seed=seed,
    )

    dmn, weights, curve = train_dmn_with_optimizer(
        X_train, y_train, optimizer_name=optimizer_name,
        max_iterations=max_iterations, pop_size=pop_size,
        n_layers=n_layers, seed=seed,
    )

    result = evaluate_dmn(dmn, weights, X_test, y_test)
    result["convergence_curve"] = curve
    return result


def run_pipeline_kfold(k: int, optimizer_name: str = "HDTBO",
                        max_iterations: int = None, pop_size: int = None,
                        apply_preprocessing: bool = True, apply_augmentation: bool = True,
                        apply_feature_fusion: bool = True, n_layers: int = None,
                        seed: int = None) -> dict:
    """
    K-fold cross-validation variant of run_pipeline: trains/evaluates once
    per fold and returns the mean metrics across folds (Section 5.6.2 /
    5.17 "K-fold cross-validation with K = 9").
    """
    max_iterations = max_iterations or config.MAX_ITERATIONS
    pop_size = pop_size or config.POP_SIZE
    seed = config.RANDOM_STATE if seed is None else seed

    df = data_utils.load_dataset()
    if apply_preprocessing:
        df = data_utils.handle_missing_values(df)
        df, _ = data_utils.min_max_normalize(df)
    feature_cols = [c for c in df.columns if c != config.LABEL_COLUMN]
    X = df[feature_cols].values.astype(np.float64)
    y = df[config.LABEL_COLUMN].values.astype(int)

    skf = StratifiedKFold(n_splits=k, shuffle=True, random_state=seed)
    fold_metrics = []

    for train_idx, test_idx in skf.split(X, y):
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]

        if apply_augmentation:
            X_train, y_train = data_utils.smote_augment(X_train, y_train, random_state=seed)

        if apply_feature_fusion:
            fusion = LevenshteinDNNFusion(random_state=seed)
            X_train = fusion.fit_transform(X_train, y_train)
            X_test = fusion.transform(X_test)

        dmn, weights, _ = train_dmn_with_optimizer(
            X_train, y_train, optimizer_name=optimizer_name,
            max_iterations=max_iterations, pop_size=pop_size,
            n_layers=n_layers, seed=seed,
        )
        fold_metrics.append(evaluate_dmn(dmn, weights, X_test, y_test))

    mean_result = {}
    std_result = {}
    for key in fold_metrics[0]:
        vals = [m[key] for m in fold_metrics]
        mean_result[key] = float(np.mean(vals))
        std_result[key] = float(np.std(vals))
    mean_result["std"] = std_result
    return mean_result
