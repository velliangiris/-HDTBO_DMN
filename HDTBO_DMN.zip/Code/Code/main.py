"""
main.py
=======
Runs the full HDTBO_DMN demo suite end to end and writes every figure
into outputs/:


  4. figure11_algorithmic_analysis.png        - optimizer comparison
  5. figure12_ablation_analysis.png           - component ablation
  6. figure13_resistance_analysis.png         - simulated attack resistance

Usage:
    python main.py                  # fast demo run (synthetic data, FAST_MODE)
    FAST_MODE=0 python main.py      # paper-scale settings (needs real BoT-IoT csv)
    BOTIOT_CSV_PATH=/path/to/BoT_IoT_5pct.csv python main.py
"""

import os
import time

import config
from auth_phase import run_authentication_protocol_demo
from performance_analysis import run_training_percentage_sweep, run_kfold_sweep
from algorithmic_analysis import run_algorithmic_analysis
from ablation_analysis import run_ablation_analysis
from resistance_analysis import run_resistance_analysis


def main():
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    t0 = time.time()

    print("=" * 70)
    print(f"HDTBO_DMN demo suite  |  FAST_MODE = {config.FAST_MODE}")
    print("=" * 70)



    print("\n[3/8] Authentication phase (Section 4.1, Figure 2 top row / Figure 3)")
    run_authentication_protocol_demo()

    print("\n[4/8] Figure 7 - Performance analysis vs training percentage")
    run_training_percentage_sweep()

    print("\n[5/8] Figure 9 - Performance analysis vs K-fold")
    run_kfold_sweep()

    print("\n[6/8] Figure 11 - Algorithmic analysis")
    run_algorithmic_analysis()

    print("\n[7/8] Figure 12 - Ablation analysis")
    run_ablation_analysis()

    print("\n[8/8] Figure 13 - Resistance analysis")
    run_resistance_analysis()

    print(f"\nDone in {time.time() - t0:.1f}s. Figures saved in '{config.OUTPUT_DIR}/'.")


if __name__ == "__main__":
    main()
