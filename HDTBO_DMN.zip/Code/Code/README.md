# Multi-Face Deep Fake Recognition based on Fractional Secretary Bird Skill Optimization-enabled hybrid Deep Learning approach using Federated Learning


## Installation

```bash
python3 -m venv venv
source venv/bin/activate            # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Download the CSV and :

```bash
python main.py
```

---

## 4. Running

```bash
python main.py


FAST_MODE=0  python main.py
```

Each experiment can also be run standalone:

```bash
python performance_analysis.py
python algorithmic_analysis.py
python ablation_analysis.py
python resistance_analysis.py
```

All figures are written to `outputs/`.

---

## 5. How the pipeline maps to the manuscript

1. **Preprocessing** (`data_utils.py`) 
2. **Data augmentation** (`data_utils.smote_augment`) 
3. **Feature fusion** (`feature_fusion.py`) 
4. **DMN classifier** (`dmn_model.py`) 
5. **HDTBO training** (`optimizers.py`)
6. **Evaluation** (`metrics.py`)

---


## 7. File overview

```
hdtbo_dmn_ids/
├── config.py                    # all hyperparameters (Table 3 & 4) + sweep values
├── data_utils.py                 # load / missing-value handling / Min-Max / SMOTE
├── feature_fusion.py             # Levenshtein distance + DNN fusion
├── dmn_model.py                  # Deep Maxout Network (NumPy, flat weight vector)
├── optimizers.py                 # Jaya, CSO, HLBO, DTBO, HDTBO (proposed), RHHO
├── auth_phase.py                 # Authentication Phase (Section 4.1, Eqs. 1-20)
├── metrics.py                    # Eqs. 61-66 + ROC-AUC
├── train_utils.py                # glues everything into run_pipeline() / run_pipeline_kfold()
├── plot_utils.py                 # shared Matplotlib helpers
├── performance_analysis.py       # Figures 7 & 9
├── algorithmic_analysis.py       # Figure 11
├── ablation_analysis.py          # Figure 12
├── resistance_analysis.py        # Figure 13
├── main.py                       # runs everything, writes outputs/
├── requirements.txt
├── README.md
└── outputs/                      # generated figures land here
```
# Minimum Hardware Requirements

| Component | Minimum Specification                                          |
|-----------|----------------------------------------------------------------|
| Operating System | Windows 10 (64-bit)                                            |
| Processor | Intel Core i3  or equivalent                                   |
| RAM | 8 GB Recommended                                               |
| GPU | Optional (CUDA-compatible GPU recommended for faster training) |
| Storage | 100 GB Free Disk Space                                         |
| Programming Language | Python 3.9.11                                                  |
---