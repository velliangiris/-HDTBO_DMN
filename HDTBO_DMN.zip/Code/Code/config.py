"""
config.py
=========
Central configuration for the HDTBO_DMN Intrusion Detection pipeline.

All values below are taken directly from the manuscript
"HDTBO_DMN: A Secure IoT-Enabled Healthcare Intrusion Detection System
for Enhanced Communication" (Table 3 - IoT simulation parameters,
Table 4 - DMN / HDTBO parameter settings, Section 5.2 - dataset details).

Where the manuscript specifies a value that is impractical to run as-is
on a laptop (e.g. 3.6 million BoT-IoT records, 8-layer DMN with 100
epochs per metaheuristic solution, population = 50 for every single
sweep point) a `FAST_MODE` switch is provided so the whole demo suite
finishes in a few minutes. Set FAST_MODE = False and point
DATA_CSV_PATH to the real BoT-IoT csv to reproduce paper-scale runs.
"""

import os

# ----------------------------------------------------------------------
# Reproducibility
# ----------------------------------------------------------------------
RANDOM_STATE = 42

# ----------------------------------------------------------------------
# Dataset (Section 5.2)
# ----------------------------------------------------------------------
# Real BoT-IoT csv (5% subset, as recommended in the paper). Download from
# https://research.unsw.edu.au/projects/bot-iot-dataset and point this to
# the extracted CSV file. If the file does not exist, a synthetic BoT-IoT
# -like dataset is generated instead so the pipeline still runs end-to-end.
DATA_CSV_PATH = os.environ.get("BOTIOT_CSV_PATH", "data/BoT_IoT_5pct.csv")
LABEL_COLUMN = "label"                 # 0 = normal, 1 = attack
N_FEATURES = 43                        # 43 independent features (paper)
TRAIN_SPLIT = 0.80                     # 80% train
VAL_SPLIT = 0.10                       # 10% validation
TEST_SPLIT = 0.10                      # 10% test

# Synthetic-data fallback size / imbalance ratio. The real dataset has
# ~3.6M rows with only 38 normal samples per 1,000,000 (extreme
# imbalance, see Table 6). Reproducing that exact ratio at demo scale
# would leave too few normal samples per split/fold to be usable, so the
# fallback generator uses a milder (but still strongly imbalanced) 5%
# normal ratio by default. Set SYNTHETIC_NORMAL_RATIO = 38/1_000_000 (and
# raise N_SYNTHETIC_SAMPLES accordingly) to mimic the paper's exact
# imbalance, or better yet point DATA_CSV_PATH at the real BoT-IoT csv.
N_SYNTHETIC_SAMPLES = 4000
SYNTHETIC_NORMAL_RATIO = 0.05

# ----------------------------------------------------------------------
# Speed switch
# ----------------------------------------------------------------------
# True  -> small population / iteration counts, quick sanity-check run
# False -> paper-scale settings from Table 4 (slow, needs real data)
FAST_MODE = os.environ.get("FAST_MODE", "1") == "1"

# ----------------------------------------------------------------------
# DMN model hyperparameters (Table 4, left column)
# ----------------------------------------------------------------------
DMN_NUM_LAYERS = 8 if not FAST_MODE else 3     # "Number of layers"
DMN_HIDDEN_UNITS = 32                          # units per hidden layer
DMN_MAXOUT_PIECES = 3                          # k linear pieces per Maxout unit
DMN_LEARNING_RATE = 0.001
DMN_BATCH_SIZE = 64
DMN_DROPOUT_RATE = 0.3
DMN_WEIGHT_DECAY = 1e-4
DMN_NUM_EPOCHS = 100 if not FAST_MODE else 15
DMN_GRADIENT_CLIP = 1.0

# ----------------------------------------------------------------------
# HDTBO / metaheuristic optimizer hyperparameters (Table 4, right column)
# ----------------------------------------------------------------------
POP_SIZE = 50 if not FAST_MODE else 12         # "Population size"
DIMENSION = 30                                 # kept for reference; the
                                                # actual solution dimension
                                                # in this implementation is
                                                # the flattened DMN weight
                                                # vector length.
LOWER_BOUND = -10.0
UPPER_BOUND = 10.0
MAX_ITERATIONS = 80 if not FAST_MODE else 20   # "Maximum iterations"
DRIVING_FACTOR = 2.0
EXPLORATION_RATE = 0.6
EXPLOITATION_RATE = 0.4
MUTATION_PROBABILITY = 0.1
HYBRID_SWITCHING_RATE = 0.5
RANDOM_NUMBER_RANGE = (0, 5)

# ----------------------------------------------------------------------
# Evaluation-figure sweep values (Sections 5.4 - 5.9)
# ----------------------------------------------------------------------
TRAINING_PERCENTAGES = [50, 60, 70, 80, 90]
ITERATION_LEGEND = [20, 40, 60, 80]
KFOLD_VALUES = [5, 6, 7, 8, 9]
SOLUTION_SIZES = [50, 60, 70, 80, 90]
ATTACK_TYPES = ["Replay", "Man-in-the-Middle", "Key-Compromise Impersonation", "Sybil"]

# Ablation variant legend (exactly as requested)
ABLATION_LEGEND = [
    "HDTBO_DMN without pre-processing",
    "HDTBO_DMN without data augmentation",
    "HDTBO_DMN without feature fusion",
    "DMN",
    "HLBO_DMN",
    "DTBO_DMN",
    "Proposed HDTBO_DMN",
]

# Algorithmic-analysis variant legend (exactly as requested)
ALGORITHM_LEGEND = [
    "Jaya + DMN",
    "CSO + DMN",
    "HLBO + DMN",
    "DTBO + DMN",
    "Proposed HDTBO + DMN",
]

# ----------------------------------------------------------------------
# Authentication phase (Section 4.1, Figure 2 top row / Figure 3)
# ----------------------------------------------------------------------
# Random numbers u, v, m, n and the security parameter are drawn from
# [0, 2] per Section 4.1.1 ("random number that lies in the range of
# [0, 2] mod [0, 2]").
AUTH_RANDOM_RANGE = (0.0, 2.0)
AUTH_KEY_BYTES = 16                 # RHHO-optimized secret key length
AUTH_KEY_DIM = 32                   # search-space dimension for RHHO
AUTH_KEY_LOWER_BOUND = 0.0
AUTH_KEY_UPPER_BOUND = 1.0
AUTH_RHHO_POP_SIZE = 20 if FAST_MODE else 50
AUTH_RHHO_MAX_ITERATIONS = 15 if FAST_MODE else 80
AUTH_OTP_VALID_SECONDS = 60         # OTP freshness window
AUTH_TIMESTAMP_MAX_DELAY = 5.0      # Eq. 17/18 timestamp validity threshold (s)

# ----------------------------------------------------------------------
# Output paths
# ----------------------------------------------------------------------
OUTPUT_DIR = "outputs"
