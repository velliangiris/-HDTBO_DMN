"""
feature_fusion.py

"""

import numpy as np

try:
    import Levenshtein as _lev
    def _edit_distance(a: str, b: str) -> int:
        return _lev.distance(a, b)
except ImportError:  # pure-python fallback, no extra dependency required
    def _edit_distance(a: str, b: str) -> int:
        if a == b:
            return 0
        if len(a) == 0:
            return len(b)
        if len(b) == 0:
            return len(a)
        prev = list(range(len(b) + 1))
        for i, ca in enumerate(a, start=1):
            curr = [i] + [0] * len(b)
            for j, cb in enumerate(b, start=1):
                cost = 0 if ca == cb else 1
                curr[j] = min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost)
            prev = curr
        return prev[-1]


_ALPHABET = "abcdefghijklmnopqrstuvwxyz"
_N_BINS = len(_ALPHABET)


def _row_to_symbolic_sequence(row: np.ndarray) -> str:
    """Quantize a normalized (0..1) feature row into a symbolic string."""
    bins = np.clip((row * (_N_BINS - 1)).astype(int), 0, _N_BINS - 1)
    return "".join(_ALPHABET[b] for b in bins)


class LevenshteinDNNFusion:
    """Levenshtein-distance + DNN feature-fusion block."""

    def __init__(self, n_references: int = 8, embedding_dim: int = 16,
                 random_state: int = 42):
        self.n_references = n_references
        self.embedding_dim = embedding_dim
        self.random_state = random_state
        self.reference_sequences_ = None
        self._W1 = None
        self._b1 = None
        self._W2 = None
        self._b2 = None
        self._fitted = False

    # -- Levenshtein similarity block ------------------------------------
    def _build_references(self, X: np.ndarray, y: np.ndarray):
        rng = np.random.default_rng(self.random_state)
        refs = []
        for cls in np.unique(y):
            cls_rows = X[y == cls]
            if len(cls_rows) == 0:
                continue
            n_pick = max(1, self.n_references // len(np.unique(y)))
            idx = rng.choice(len(cls_rows), size=min(n_pick, len(cls_rows)),
                              replace=False)
            for i in idx:
                refs.append(_row_to_symbolic_sequence(cls_rows[i]))
        self.reference_sequences_ = refs

    def _levenshtein_features(self, X: np.ndarray) -> np.ndarray:
        seqs = [_row_to_symbolic_sequence(r) for r in X]
        n_refs = len(self.reference_sequences_)
        L = np.zeros((len(seqs), n_refs), dtype=np.float64)
        seq_len = X.shape[1]
        for i, s in enumerate(seqs):
            for j, ref in enumerate(self.reference_sequences_):
                L[i, j] = _edit_distance(s, ref) / max(seq_len, 1)
        return L

    # -- Small DNN encoder (backprop-trained, independent of HDTBO) ------
    def _init_dnn(self, input_dim: int):
        rng = np.random.default_rng(self.random_state)
        hidden = max(8, self.embedding_dim)
        self._W1 = rng.normal(0, np.sqrt(2.0 / input_dim), size=(input_dim, hidden))
        self._b1 = np.zeros(hidden)
        self._W2 = rng.normal(0, np.sqrt(2.0 / hidden), size=(hidden, self.embedding_dim))
        self._b2 = np.zeros(self.embedding_dim)

    @staticmethod
    def _relu(z):
        return np.maximum(0, z)

    def _dnn_forward(self, X: np.ndarray) -> np.ndarray:
        h = self._relu(X @ self._W1 + self._b1)
        out = self._relu(h @ self._W2 + self._b2)
        return out

    def _dnn_finetune(self, X: np.ndarray, y: np.ndarray, epochs: int = 30,
                       lr: float = 0.05):
        """
        Lightweight supervised fine-tuning of the fusion encoder so the
        fused embedding is class-discriminative (simple logistic read-out
        trained jointly with the encoder via numerical gradient-free
        coordinate updates -- keeps the module dependency-free while still
        being genuinely data-driven rather than a fixed random projection).
        """
        rng = np.random.default_rng(self.random_state)
        n, d = X.shape
        w_out = rng.normal(0, 0.1, size=self.embedding_dim)
        b_out = 0.0
        y = y.astype(np.float64)

        for _ in range(epochs):
            emb = self._dnn_forward(X)
            logits = emb @ w_out + b_out
            preds = 1.0 / (1.0 + np.exp(-logits))
            grad = preds - y

            # output layer gradient
            grad_w_out = emb.T @ grad / n
            grad_b_out = grad.mean()
            w_out -= lr * grad_w_out
            b_out -= lr * grad_b_out

            # crude encoder update: nudge W2 in the direction that reduces
            # classification error (keeps encoder trainable without a full
            # autodiff dependency)
            h = self._relu(X @ self._W1 + self._b1)
            d_emb = np.outer(grad, w_out) / n
            d_emb *= (emb > 0)
            grad_W2 = h.T @ d_emb
            grad_b2 = d_emb.sum(axis=0)
            self._W2 -= lr * grad_W2
            self._b2 -= lr * grad_b2

    def fit(self, X: np.ndarray, y: np.ndarray):
        self._build_references(X, y)
        lev_feats = self._levenshtein_features(X)
        fusion_input = np.hstack([X, lev_feats])
        self._init_dnn(fusion_input.shape[1])
        self._dnn_finetune(fusion_input, y)
        self._fitted = True
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        if not self._fitted:
            raise RuntimeError("Call fit() before transform().")
        lev_feats = self._levenshtein_features(X)
        fusion_input = np.hstack([X, lev_feats])
        return self._dnn_forward(fusion_input)

    def fit_transform(self, X: np.ndarray, y: np.ndarray) -> np.ndarray:
        self.fit(X, y)
        return self.transform(X)
