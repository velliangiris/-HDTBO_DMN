"""
plot_utils.py
=============
Shared Matplotlib helpers so every experiment script produces figures in
a consistent manuscript-like style (grouped bar charts with one group per
x-axis value and one bar per legend entry).
"""

import os
import numpy as np
import matplotlib.pyplot as plt

METRIC_TITLES = {
    "attack_detection_rate": "Attack Detection Rate",
    "f1_score": "F1-score",
    "fpr": "False Positive Rate (FPR)",
    "precision": "Precision",
    "accuracy": "Accuracy",
    "mcc": "MCC",
    "roc_auc": "ROC-AUC",
}


def grouped_bar_chart(ax, x_labels, series: dict, ylabel: str, title: str,
                       xlabel: str = ""):
    """
    series: {legend_label: [value_per_x_label, ...]}
    """
    n_groups = len(x_labels)
    n_series = len(series)
    width = 0.8 / max(n_series, 1)
    x = np.arange(n_groups)

    for i, (label, values) in enumerate(series.items()):
        offset = (i - (n_series - 1) / 2) * width
        ax.bar(x + offset, values, width=width, label=label)

    ax.set_xticks(x)
    ax.set_xticklabels(x_labels)
    ax.set_ylabel(ylabel)
    ax.set_xlabel(xlabel)
    ax.set_title(title, fontsize=10)
    ax.legend(fontsize=6.5, loc="lower right")
    ax.grid(axis="y", linestyle="--", alpha=0.4)


def multi_panel_metric_figure(x_labels, results: dict, metrics: list,
                               suptitle: str, save_path: str, xlabel: str,
                               ncols: int = 3):
    """
    results: {legend_label: {metric_name: [value_per_x_label, ...]}}
    metrics: ordered list of metric keys to plot, one subplot each.
    """
    nrows = int(np.ceil(len(metrics) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(5.2 * ncols, 4.2 * nrows))
    axes = np.array(axes).reshape(-1)
    panel_letters = "abcdefghijkl"

    for idx, metric in enumerate(metrics):
        series = {label: results[label][metric] for label in results}
        title = f"{panel_letters[idx]}) {METRIC_TITLES.get(metric, metric)}"
        grouped_bar_chart(axes[idx], x_labels, series,
                           ylabel=METRIC_TITLES.get(metric, metric),
                           title=title, xlabel=xlabel)

    for j in range(len(metrics), len(axes)):
        axes[j].axis("off")

    fig.suptitle(suptitle, fontsize=13, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    fig.savefig(save_path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    print(f"[plot_utils] saved -> {save_path}")


def line_chart(x_labels, series: dict, ylabel: str, title: str, xlabel: str,
                save_path: str):
    fig, ax = plt.subplots(figsize=(7, 5))
    for label, values in series.items():
        ax.plot(x_labels, values, marker="o", label=label)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontsize=11, fontweight="bold")
    ax.legend(fontsize=8)
    ax.grid(linestyle="--", alpha=0.4)
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    fig.tight_layout()
    fig.savefig(save_path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    print(f"[plot_utils] saved -> {save_path}")
