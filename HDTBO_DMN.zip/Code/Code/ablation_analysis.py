"""
ablation_analysis.py

  ['HDTBO_DMN without pre-processing', 'HDTBO_DMN without data augmentation',
   'HDTBO_DMN without feature fusion', 'DMN', 'HLBO_DMN', 'DTBO_DMN',
   'Proposed HDTBO_DMN']

Variant definitions
--------------------
- "HDTBO_DMN without pre-processing" : full pipeline, missing-value
  handling + Min-Max normalization disabled (SMOTE + feature fusion +
  HDTBO all kept).
- "HDTBO_DMN without data augmentation" : SMOTE disabled, everything
  else kept.
- "HDTBO_DMN without feature fusion" : Levenshtein+DNN fusion disabled,
  everything else kept.
- "DMN" : full preprocessing pipeline kept, but the DMN is optimized
  with the simplest baseline optimizer (Jaya) instead of HDTBO --
  representing a plain DMN with no advanced metaheuristic tuning.
- "HLBO_DMN" : full pipeline, DMN optimized with HLBO alone.
- "DTBO_DMN" : full pipeline, DMN optimized with DTBO alone.
- "Proposed HDTBO_DMN" : the complete proposed pipeline.
"""

import os
import config
import train_utils
from plot_utils import multi_panel_metric_figure

VARIANTS = {
    "HDTBO_DMN without pre-processing": dict(
        optimizer_name="HDTBO", apply_preprocessing=False,
        apply_augmentation=True, apply_feature_fusion=True),
    "HDTBO_DMN without data augmentation": dict(
        optimizer_name="HDTBO", apply_preprocessing=True,
        apply_augmentation=False, apply_feature_fusion=True),
    "HDTBO_DMN without feature fusion": dict(
        optimizer_name="HDTBO", apply_preprocessing=True,
        apply_augmentation=True, apply_feature_fusion=False),
    "DMN": dict(
        optimizer_name="Jaya", apply_preprocessing=True,
        apply_augmentation=True, apply_feature_fusion=True),
    "HLBO_DMN": dict(
        optimizer_name="HLBO", apply_preprocessing=True,
        apply_augmentation=True, apply_feature_fusion=True),
    "DTBO_DMN": dict(
        optimizer_name="DTBO", apply_preprocessing=True,
        apply_augmentation=True, apply_feature_fusion=True),
    "Proposed HDTBO_DMN": dict(
        optimizer_name="HDTBO", apply_preprocessing=True,
        apply_augmentation=True, apply_feature_fusion=True),
}

METRICS = ["accuracy"]


def run_ablation_analysis():
    assert list(VARIANTS.keys()) == config.ABLATION_LEGEND, \
        "VARIANTS keys must match config.ABLATION_LEGEND exactly"

    results = {legend: {"accuracy": []} for legend in config.ABLATION_LEGEND}

    for train_pct in config.TRAINING_PERCENTAGES:
        for legend, kwargs in VARIANTS.items():
            print(f"[ablation_analysis] train%={train_pct}, variant='{legend}'")
            res = train_utils.run_pipeline(
                train_pct=train_pct, max_iterations=config.MAX_ITERATIONS,
                pop_size=config.POP_SIZE, **kwargs,
            )
            results[legend]["accuracy"].append(res["accuracy"])

    save_path = os.path.join(config.OUTPUT_DIR, "figure12_ablation_analysis.png")
    multi_panel_metric_figure(
        x_labels=[f"{p}%" for p in config.TRAINING_PERCENTAGES],
        results=results, metrics=METRICS,
        suptitle="Figure 12. Ablation analysis\n"
                  "(varying training percentage, accuracy)",
        save_path=save_path, xlabel="Training data percentage", ncols=1,
    )
    return results


if __name__ == "__main__":
    run_ablation_analysis()
