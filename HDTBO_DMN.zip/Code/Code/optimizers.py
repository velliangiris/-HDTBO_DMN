"""
optimizers.py
=============
Metaheuristic optimizers used to train / benchmark the DMN classifier:

  - Jaya            [43]  (baseline, algorithmic-analysis legend)
  - CSO              [44]  (baseline, Competitive Swarm Optimizer, algorithmic-analysis legend)
  - HLBO             [40]  (Hybrid Leader-Based Optimization, ablation legend "HLBO_DMN")
  - DTBO             [41]  (Driving Training-Based Optimization, ablation legend "DTBO_DMN")
  - HDTBO (proposed)        (Section 4.2.5(b): hybridizes HLBO exploration with
                             DTBO exploitation, switching adaptively based on
                             fitness-improvement -- Eqs. 42-60 of the manuscript)
  - RHHO                    (Section 4.1.5(a): hybridizes ROA [Rider
                             Optimization Algorithm] with HOA [Horse Herd
                             Optimization Algorithm] -- Eq. 11 of the
                             manuscript. Used by auth_phase.py to generate the
                             secret encryption key in the Data Protection
                             stage; NOT used to train the DMN classifier.)

Every optimizer shares the same minimal interface so it can be swapped
in transparently for the algorithmic-analysis / ablation-analysis
experiments:

    best_solution, best_fitness, curve = optimizer.optimize(
        fitness_fn, dim, lower_bound, upper_bound, pop_size, max_iterations
    )

`fitness_fn` must be a function `f(solution: np.ndarray) -> float` where
LOWER is better (the optimizers minimize).
"""

import numpy as np

import config


class BaseOptimizer:
    name = "base"

    def __init__(self, seed: int = None):
        self.seed = config.RANDOM_STATE if seed is None else seed
        self._rng = np.random.default_rng(self.seed)

    def _init_population(self, pop_size, dim, lb, ub):
        return self._rng.uniform(lb, ub, size=(pop_size, dim))

    def optimize(self, fitness_fn, dim, lower_bound, upper_bound, pop_size,
                 max_iterations):
        raise NotImplementedError


# ---------------------------------------------------------------------
# Jaya  (no algorithm-specific parameters, "always move toward the
#        best and away from the worst")
# ---------------------------------------------------------------------
class Jaya(BaseOptimizer):
    name = "Jaya"

    def optimize(self, fitness_fn, dim, lower_bound, upper_bound, pop_size,
                 max_iterations):
        lb, ub = lower_bound, upper_bound
        pop = self._init_population(pop_size, dim, lb, ub)
        fitness = np.array([fitness_fn(ind) for ind in pop])
        curve = []

        for it in range(max_iterations):
            best = pop[fitness.argmin()]
            worst = pop[fitness.argmax()]
            r1 = self._rng.random((pop_size, dim))
            r2 = self._rng.random((pop_size, dim))
            new_pop = pop + r1 * (best - np.abs(pop)) - r2 * (worst - np.abs(pop))
            new_pop = np.clip(new_pop, lb, ub)
            new_fit = np.array([fitness_fn(ind) for ind in new_pop])
            improve = new_fit < fitness
            pop[improve] = new_pop[improve]
            fitness[improve] = new_fit[improve]
            curve.append(fitness.min())

        best_idx = fitness.argmin()
        return pop[best_idx], fitness[best_idx], curve


# ---------------------------------------------------------------------
# CSO -- Competitive Swarm Optimizer
# ---------------------------------------------------------------------
class CSO(BaseOptimizer):
    name = "CSO"

    def optimize(self, fitness_fn, dim, lower_bound, upper_bound, pop_size,
                 max_iterations):
        lb, ub = lower_bound, upper_bound
        pop = self._init_population(pop_size, dim, lb, ub)
        vel = np.zeros((pop_size, dim))
        fitness = np.array([fitness_fn(ind) for ind in pop])
        curve = []

        for it in range(max_iterations):
            order = self._rng.permutation(pop_size)
            mean_pos = pop.mean(axis=0)
            for i in range(0, pop_size - 1, 2):
                a, b = order[i], order[i + 1]
                if fitness[a] <= fitness[b]:
                    winner, loser = a, b
                else:
                    winner, loser = b, a
                r1, r2, r3 = self._rng.random(dim), self._rng.random(dim), self._rng.random(dim)
                vel[loser] = (r1 * vel[loser]
                              + r2 * (pop[winner] - pop[loser])
                              + r3 * config.HYBRID_SWITCHING_RATE * (mean_pos - pop[loser]))
                pop[loser] = np.clip(pop[loser] + vel[loser], lb, ub)
                fitness[loser] = fitness_fn(pop[loser])
            curve.append(fitness.min())

        best_idx = fitness.argmin()
        return pop[best_idx], fitness[best_idx], curve


# ---------------------------------------------------------------------
# HLBO -- Hybrid Leader-Based Optimization
# (population-based; a single "hybrid leader" guides all members,
#  strengthening global exploration -- text around Eqs. 46-49)
# ---------------------------------------------------------------------
class HLBO(BaseOptimizer):
    name = "HLBO"

    def optimize(self, fitness_fn, dim, lower_bound, upper_bound, pop_size,
                 max_iterations):
        lb, ub = lower_bound, upper_bound
        pop = self._init_population(pop_size, dim, lb, ub)
        fitness = np.array([fitness_fn(ind) for ind in pop])
        curve = []

        for it in range(max_iterations):
            leader = pop[fitness.argmin()]
            # hybrid leader = weighted blend of global best and population centroid
            hybrid_leader = 0.5 * leader + 0.5 * pop.mean(axis=0)
            explore_rate = config.EXPLORATION_RATE * (1 - it / max_iterations)

            r = self._rng.random((pop_size, dim))
            rand_walk = self._rng.uniform(-1, 1, size=(pop_size, dim))
            new_pop = pop + r * (hybrid_leader - pop) + explore_rate * rand_walk
            new_pop = np.clip(new_pop, lb, ub)
            new_fit = np.array([fitness_fn(ind) for ind in new_pop])
            improve = new_fit < fitness
            pop[improve] = new_pop[improve]
            fitness[improve] = new_fit[improve]
            curve.append(fitness.min())

        best_idx = fitness.argmin()
        return pop[best_idx], fitness[best_idx], curve

    @staticmethod
    def hybrid_leader(pop, fitness):
        leader = pop[fitness.argmin()]
        return 0.5 * leader + 0.5 * pop.mean(axis=0)


# ---------------------------------------------------------------------
# DTBO -- Driving Training-Based Optimization
# Three phases per Section 4.2.5(b):
#   1) training by driving instructor (exploration phase 1, Eqs. 42-45)
#   2) patterning of the instructor's skills (exploration phase 2, Eqs. 55-58)
#   3) self-practice (exploitation phase, Eqs. 59-60)
# ---------------------------------------------------------------------
class DTBO(BaseOptimizer):
    name = "DTBO"

    def optimize(self, fitness_fn, dim, lower_bound, upper_bound, pop_size,
                 max_iterations):
        lb, ub = lower_bound, upper_bound
        pop = self._init_population(pop_size, dim, lb, ub)
        fitness = np.array([fitness_fn(ind) for ind in pop])
        curve = []
        n_instructors = max(1, pop_size // 5)

        for it in range(max_iterations):
            order = fitness.argsort()
            instructors = pop[order[:n_instructors]]

            # Phase 1: training by driving instructor
            for i in range(pop_size):
                instructor = instructors[self._rng.integers(0, n_instructors)]
                I = self._rng.integers(1, 3)  # teaching factor in {1, 2}
                r = self._rng.random(dim)
                candidate = pop[i] + r * (instructor - I * pop[i])
                candidate = np.clip(candidate, lb, ub)
                f_new = fitness_fn(candidate)
                if f_new < fitness[i]:
                    pop[i], fitness[i] = candidate, f_new

            # Phase 2: patterning of the instructor's skills
            best = pop[fitness.argmin()]
            for i in range(pop_size):
                pattern_idx = self._rng.random(dim) < 0.5
                candidate = pop[i].copy()
                candidate[pattern_idx] = (pop[i][pattern_idx]
                                          + self._rng.random(pattern_idx.sum())
                                          * (best[pattern_idx] - pop[i][pattern_idx]))
                candidate = np.clip(candidate, lb, ub)
                f_new = fitness_fn(candidate)
                if f_new < fitness[i]:
                    pop[i], fitness[i] = candidate, f_new

            # Phase 3: self-practice (local exploitation around own position)
            t = it + 1
            step = (ub - lb) * (1 - t / max_iterations) * 0.05
            for i in range(pop_size):
                candidate = pop[i] + step * self._rng.uniform(-1, 1, size=dim)
                candidate = np.clip(candidate, lb, ub)
                f_new = fitness_fn(candidate)
                if f_new < fitness[i]:
                    pop[i], fitness[i] = candidate, f_new

            curve.append(fitness.min())

        best_idx = fitness.argmin()
        return pop[best_idx], fitness[best_idx], curve


# ---------------------------------------------------------------------
# HDTBO -- proposed hybrid (Section 4.2.5(b))
# Unified position-update law combining DTBO's Driving Instructor (DI)
# with HLBO's Hybrid Leader (HL) in a single equation every iteration
# (confirmed against the manuscript by hand -- not a per-iteration
# switch between two separate HLBO-style / DTBO-style steps):
#
#     x_i,j(t+1) = 1/(gamma*(1+I)) * [(gamma*r*DI)*(1+gamma) - gamma*HL]
#
# where:
#   DI     Driving Instructor -- the best member of a small elite pool
#          (DTBO), one drawn per solution i, matching the existing
#          n_instructors pool used elsewhere in this file.
#   HL     Hybrid Leader (HLBO.hybrid_leader) -- blend of the global
#          best and the population centroid, shared by the whole swarm.
#   I      DTBO teaching factor, integer in {1, 2}.
#   r      uniform random vector in (0, 1), one draw per dimension.
#   gamma  adaptive blending coefficient in (0, 1); driven toward 1
#          (more exploration / HL-weighted) as a solution's fitness
#          stagnates, and toward EXPLOITATION_RATE (more DI-weighted)
#          otherwise -- this is what realizes "adaptively switches
#          between [HLBO exploration and DTBO exploitation] based on
#          fitness-improvement stagnation" from Section 4.2.5(b) without
#          needing a hard if/else branch.
# ---------------------------------------------------------------------
class HDTBO(BaseOptimizer):
    name = "HDTBO (Proposed)"

    def optimize(self, fitness_fn, dim, lower_bound, upper_bound, pop_size,
                 max_iterations):
        lb, ub = lower_bound, upper_bound
        pop = self._init_population(pop_size, dim, lb, ub)
        fitness = np.array([fitness_fn(ind) for ind in pop])
        curve = []
        n_instructors = max(1, pop_size // 5)

        stagnation_counter = np.zeros(pop_size, dtype=int)

        for it in range(max_iterations):
            order = fitness.argsort()
            instructors = pop[order[:n_instructors]]
            HL = HLBO.hybrid_leader(pop, fitness)

            for i in range(pop_size):
                DI = instructors[self._rng.integers(0, n_instructors)]
                I = self._rng.integers(1, 3)                 # DTBO teaching factor {1, 2}
                r = self._rng.random(dim)

                # gamma: more stagnation -> closer to 1 (lean on HL / explore);
                # fresh improvement -> closer to EXPLOITATION_RATE (lean on DI)
                stagnation_frac = min(stagnation_counter[i] / 5.0, 1.0)
                gamma_center = (config.EXPLOITATION_RATE
                                + stagnation_frac * (1.0 - config.EXPLOITATION_RATE))
                gamma = np.clip(gamma_center + self._rng.uniform(-0.05, 0.05), 0.05, 0.95)

                candidate = (1.0 / (gamma * (1 + I))) * (
                    (gamma * r * DI) * (1 + gamma) - gamma * HL
                )

                # occasional mutation (Table 4: mutation probability 0.1)
                if self._rng.random() < config.MUTATION_PROBABILITY:
                    mutate_idx = self._rng.integers(0, dim)
                    candidate[mutate_idx] = self._rng.uniform(lb, ub)

                candidate = np.clip(candidate, lb, ub)
                f_new = fitness_fn(candidate)

                if f_new < fitness[i]:
                    pop[i], fitness[i] = candidate, f_new
                    stagnation_counter[i] = 0
                else:
                    stagnation_counter[i] += 1

            # DTBO self-practice pass for the current elite (Eqs. 59-60)
            best_idx = fitness.argmin()
            t = it + 1
            step = (ub - lb) * (1 - t / max_iterations) * 0.03
            candidate = pop[best_idx] + step * self._rng.uniform(-1, 1, size=dim)
            candidate = np.clip(candidate, lb, ub)
            f_new = fitness_fn(candidate)
            if f_new < fitness[best_idx]:
                pop[best_idx], fitness[best_idx] = candidate, f_new

            curve.append(fitness.min())

        best_idx = fitness.argmin()
        return pop[best_idx], fitness[best_idx], curve


# ---------------------------------------------------------------------
# RHHO -- Rider + Horse Herd Optimization (Section 4.1.5(a), Eq. 11)
#
# Used by the Authentication Phase (auth_phase.py) to search for the
# secret key that maximizes the "randomness fitness" of the RHHO-keyed
# stream cipher used in the Data Protection stage. This is a DIFFERENT
# optimizer/objective from HDTBO (which trains DMN weights) -- Figure 2
# shows both boxes ("Data Protection (RHHO key)" and "Proposed HDTBO ...
# trains DMN weights") as separate pipeline stages.
#
# ROA contributes four rider groups (bypass / follower / overtaker /
# attacker) that each pursue the leading solution with a different
# strategy (Section 4.1.5(a) references [21]); HOA contributes an
# age-structured herd (Section 4.1.5(a) references [22]) whose members
# are pulled toward a randomly chosen herd-mate x_xi. The manuscript's
# single explicit equation for the hybrid (Eq. 11) is:
#
#     x_mn^age(t+1) = delta / (delta*alpha_mn - 1)
#                     * [alpha_mn * V_mn^age(t+1) - x_xi,mn(t) * (1 - alpha_mn)]
#
# implemented literally below, with V (the rider-group velocity term)
# computed per the four ROA rider strategies and alpha_mn (the
# hybridization coefficient) drawn per Table 4's random-number range.
# As with HDTBO/DTBO/HLBO (see README Section 6), the surrounding ROA/
# HOA equations are embedded as image objects in the manuscript and are
# realized here from their described behaviour rather than transcribed
# equation-for-equation; swap in exact equations if you have them as
# text/LaTeX.
# ---------------------------------------------------------------------
class RHHO(BaseOptimizer):
    name = "RHHO"

    # four ROA rider groups, equal split of the population
    RIDER_GROUPS = ("bypass", "follower", "overtaker", "attacker")

    def _rider_velocity(self, group, pop_i, leader, second_best, pop_mean, ub, lb, it, max_it):
        span = ub - lb
        if group == "bypass":
            # explores an independent random direction, ignoring the leader
            return self._rng.uniform(-1, 1, size=pop_i.shape) * span * 0.1
        elif group == "follower":
            # steers directly toward the current leading rider
            return self._rng.random(pop_i.shape) * (leader - pop_i)
        elif group == "overtaker":
            # blends leader- and second-best-directed steps to try to pass the leader
            r1, r2 = self._rng.random(pop_i.shape), self._rng.random(pop_i.shape)
            return r1 * (leader - pop_i) + r2 * (second_best - pop_i)
        else:  # attacker
            # drives straight at the leader's position with a decaying step
            decay = 1 - it / max_it
            return decay * (leader - pop_mean) + self._rng.random(pop_i.shape) * (leader - pop_i)

    def optimize(self, fitness_fn, dim, lower_bound, upper_bound, pop_size,
                 max_iterations):
        lb, ub = lower_bound, upper_bound
        pop = self._init_population(pop_size, dim, lb, ub)
        fitness = np.array([fitness_fn(ind) for ind in pop])
        curve = []

        group_of = [self.RIDER_GROUPS[i % 4] for i in range(pop_size)]

        for it in range(1, max_iterations + 1):
            order = fitness.argsort()
            leader = pop[order[0]]
            second_best = pop[order[1]] if pop_size > 1 else leader
            pop_mean = pop.mean(axis=0)

            new_pop = np.empty_like(pop)
            for i in range(pop_size):
                V = self._rider_velocity(group_of[i], pop[i], leader, second_best,
                                          pop_mean, ub, lb, it, max_iterations)
                # HOA neighbour: a randomly chosen herd-mate x_xi
                xi = self._rng.integers(0, pop_size)
                x_xi = pop[xi]

                delta = self._rng.uniform(0.05, 0.95)          # random constant, Eq. 11
                alpha = self._rng.uniform(0.05, 0.95, size=dim)  # hybridization coeff alpha_mn
                denom = delta * alpha - 1
                denom = np.where(np.abs(denom) < 1e-3, np.sign(denom + 1e-9) * 1e-3, denom)

                candidate = (delta / denom) * (alpha * V - x_xi * (1 - alpha))
                # Eq. 11 is a positioning law, not a step; treat its output as a
                # pull target and move a bounded fraction of the way toward it
                # so the search remains stable for arbitrary problem scales.
                step = 0.1 * (1 - 0.5 * it / max_iterations)
                new_pop[i] = pop[i] + step * (np.clip(candidate, lb, ub) - pop[i])

            new_pop = np.clip(new_pop, lb, ub)
            new_fit = np.array([fitness_fn(ind) for ind in new_pop])
            improve = new_fit < fitness
            pop[improve] = new_pop[improve]
            fitness[improve] = new_fit[improve]
            curve.append(fitness.min())

        best_idx = fitness.argmin()
        return pop[best_idx], fitness[best_idx], curve


OPTIMIZER_REGISTRY = {
    "Jaya": Jaya,
    "CSO": CSO,
    "HLBO": HLBO,
    "DTBO": DTBO,
    "HDTBO": HDTBO,
    "RHHO": RHHO,
}


def get_optimizer(name: str, seed: int = None) -> BaseOptimizer:
    if name not in OPTIMIZER_REGISTRY:
        raise ValueError(f"Unknown optimizer '{name}'. Options: {list(OPTIMIZER_REGISTRY)}")
    return OPTIMIZER_REGISTRY[name](seed=seed)
