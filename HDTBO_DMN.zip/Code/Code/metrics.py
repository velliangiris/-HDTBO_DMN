"""
metrics.py
==========
Evaluation metrics, Section 5.3 of the manuscript (Eqs. 61-66):
  5.3.1 Attack detection rate
  5.3.2 F1-score
  5.3.3 False Positive Rate (FPR)
  5.3.4 Precision
  5.3.5 Accuracy
  5.3.6 Matthews Correlation Coefficient (MCC)
  5.3.7 ROC-AUC
"""

import numpy as np
from sklearn.metrics import roc_auc_score


def confusion_counts(y_true: np.ndarray, y_pred: np.ndarray):
    tp = int(np.sum((y_true == 1) & (y_pred == 1)))
    tn = int(np.sum((y_true == 0) & (y_pred == 0)))
    fp = int(np.sum((y_true == 0) & (y_pred == 1)))
    fn = int(np.sum((y_true == 1) & (y_pred == 0)))
    return tp, tn, fp, fn


def attack_detection_rate(y_true, y_pred) -> float:
    """(TP + TN) / (TP + TN + FP + FN) — Eq. 61."""
    tp, tn, fp, fn = confusion_counts(y_true, y_pred)
    denom = tp + tn + fp + fn
    return (tp + tn) / denom if denom else 0.0


def f1_score(y_true, y_pred) -> float:
    """Harmonic mean of precision and recall — Eq. 62."""
    tp, tn, fp, fn = confusion_counts(y_true, y_pred)
    prec = tp / (tp + fp) if (tp + fp) else 0.0
    rec = tp / (tp + fn) if (tp + fn) else 0.0
    return 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0


def fpr(y_true, y_pred) -> float:
    """FP / (FP + TN) — Eq. 63."""
    tp, tn, fp, fn = confusion_counts(y_true, y_pred)
    return fp / (fp + tn) if (fp + tn) else 0.0


def precision(y_true, y_pred) -> float:
    """TP / (TP + FP) — Eq. 64."""
    tp, tn, fp, fn = confusion_counts(y_true, y_pred)
    return tp / (tp + fp) if (tp + fp) else 0.0


def recall(y_true, y_pred) -> float:
    tp, tn, fp, fn = confusion_counts(y_true, y_pred)
    return tp / (tp + fn) if (tp + fn) else 0.0


def accuracy(y_true, y_pred) -> float:
    """(TP + TN) / total — Eq. 65."""
    tp, tn, fp, fn = confusion_counts(y_true, y_pred)
    total = tp + tn + fp + fn
    return (tp + tn) / total if total else 0.0


def mcc(y_true, y_pred) -> float:
    """Matthews Correlation Coefficient — Eq. 66."""
    tp, tn, fp, fn = confusion_counts(y_true, y_pred)
    numerator = (tp * tn) - (fp * fn)
    denominator = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    return numerator / denominator if denominator else 0.0


def roc_auc(y_true, y_score) -> float:
    """ROC-AUC — Section 5.3.7. y_score = predicted probability of class 1."""
    try:
        return roc_auc_score(y_true, y_score)
    except ValueError:
        return float("nan")


def all_metrics(y_true, y_pred, y_score=None) -> dict:
    result = {
        "attack_detection_rate": attack_detection_rate(y_true, y_pred),
        "f1_score": f1_score(y_true, y_pred),
        "fpr": fpr(y_true, y_pred),
        "precision": precision(y_true, y_pred),
        "accuracy": accuracy(y_true, y_pred),
        "mcc": mcc(y_true, y_pred),
    }
    if y_score is not None:
        result["roc_auc"] = roc_auc(y_true, y_score)
    return result
