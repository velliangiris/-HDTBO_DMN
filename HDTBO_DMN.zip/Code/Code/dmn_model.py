"""
dmn_model.py
============
Deep Maxout Network (DMN), Section 4.2.5(a) of the manuscript.

"The activation parameter is replaced with the Maxout unit... The
Maxout is a general kind of ReLU that applies the max operation on k
trainable linear parameters" (Eq. 38).

Because DMN in this paper is trained by a metaheuristic optimizer
(HDTBO) rather than backpropagation, the network is implemented with a
pure NumPy forward pass whose *entire parameter set is a single flat
weight vector*. Any metaheuristic optimizer (Jaya / CSO / HLBO / DTBO /
HDTBO) can therefore optimize the network simply by proposing candidate
weight vectors and evaluating the fitness function in optimizers.py.
"""

import numpy as np


class DeepMaxoutNetwork:
    """
    Maxout feed-forward network.

    layer_sizes: e.g. [n_in, 32, 32, 16, 2] (last = number of classes)
    k_pieces: number of trainable linear pieces per Maxout unit (Eq. 38)
    """

    def __init__(self, layer_sizes, k_pieces: int = 3, dropout_rate: float = 0.3,
                 seed: int = 42):
        self.layer_sizes = list(layer_sizes)
        self.k_pieces = k_pieces
        self.dropout_rate = dropout_rate
        self.n_layers = len(self.layer_sizes) - 1
        self._rng = np.random.default_rng(seed)
        self._shapes = self._compute_shapes()
        self.dim = sum(int(np.prod(w_shape)) + int(np.prod(b_shape))
                        for _, w_shape, b_shape in self._shapes)

    def _compute_shapes(self):
        shapes = []
        for i in range(self.n_layers):
            in_dim = self.layer_sizes[i]
            out_dim = self.layer_sizes[i + 1]
            if i < self.n_layers - 1:
                # Maxout layer: k pieces, each a full (in_dim -> out_dim) linear map
                shapes.append(("maxout", (self.k_pieces, in_dim, out_dim), (self.k_pieces, out_dim)))
            else:
                # final linear + softmax layer
                shapes.append(("linear", (in_dim, out_dim), (out_dim,)))
        return shapes

    def random_weights(self) -> np.ndarray:
        """He-style random initialization, flattened into one vector."""
        vec = []
        for kind, w_shape, b_shape in self._shapes:
            fan_in = w_shape[-2]
            std = np.sqrt(2.0 / max(fan_in, 1))
            vec.append(self._rng.normal(0, std, size=w_shape).ravel())
            vec.append(np.zeros(b_shape).ravel())
        return np.concatenate(vec)

    def _unflatten(self, weight_vector: np.ndarray):
        params = []
        idx = 0
        for kind, w_shape, b_shape in self._shapes:
            w_size = int(np.prod(w_shape))
            b_size = int(np.prod(b_shape))
            W = weight_vector[idx: idx + w_size].reshape(w_shape)
            idx += w_size
            b = weight_vector[idx: idx + b_size].reshape(b_shape)
            idx += b_size
            params.append((kind, W, b))
        return params

    @staticmethod
    def _softmax(z):
        z = z - z.max(axis=1, keepdims=True)
        e = np.exp(z)
        return e / e.sum(axis=1, keepdims=True)

    def forward(self, X: np.ndarray, weight_vector: np.ndarray,
                training: bool = False) -> np.ndarray:
        """Returns softmax class probabilities, shape (n_samples, n_classes)."""
        params = self._unflatten(weight_vector)
        a = X
        for layer_idx, (kind, W, b) in enumerate(params):
            if kind == "maxout":
                # a: (n, in_dim), W: (k, in_dim, out_dim), b: (k, out_dim)
                pieces = np.einsum("ni,kio->nko", a, W) + b[None, :, :]
                a = pieces.max(axis=1)  # Eq. 38: max over k linear pieces
                if training and self.dropout_rate > 0:
                    mask = self._rng.binomial(1, 1 - self.dropout_rate, size=a.shape)
                    a = a * mask / (1 - self.dropout_rate)
            else:
                logits = a @ W + b
                a = self._softmax(logits)
        return a

    def predict_proba(self, X: np.ndarray, weight_vector: np.ndarray) -> np.ndarray:
        return self.forward(X, weight_vector, training=False)

    def predict(self, X: np.ndarray, weight_vector: np.ndarray) -> np.ndarray:
        return self.predict_proba(X, weight_vector).argmax(axis=1)


def build_dmn(input_dim: int, n_classes: int = 2, n_layers: int = 3,
              hidden_units: int = 32, k_pieces: int = 3,
              dropout_rate: float = 0.3, seed: int = 42) -> DeepMaxoutNetwork:
    """Convenience builder matching config.py hyperparameters."""
    layer_sizes = [input_dim] + [hidden_units] * max(1, n_layers - 1) + [n_classes]
    return DeepMaxoutNetwork(layer_sizes, k_pieces=k_pieces,
                              dropout_rate=dropout_rate, seed=seed)
