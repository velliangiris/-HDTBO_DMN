"""
resistance_analysis.py

"""

import os
import numpy as np

import config
import train_utils
from dmn_model import DeepMaxoutNetwork
from plot_utils import line_chart
import metrics as metrics_mod


def _simulate_replay(X, y, rng, frac=0.15):
    attack_idx = np.where(y == 1)[0]
    n = max(1, int(frac * len(attack_idx)))
    dup_idx = rng.choice(attack_idx, size=n, replace=True)
    X_rep = np.vstack([X, X[dup_idx]])
    y_rep = np.concatenate([y, y[dup_idx]])
    return X_rep, y_rep


def _simulate_mitm(X, y, rng, frac=0.25, noise_scale=0.15):
    X = X.copy()
    n = int(frac * len(X))
    idx = rng.choice(len(X), size=n, replace=False)
    X[idx] += rng.normal(0, noise_scale, size=(n, X.shape[1]))
    X[idx] = np.clip(X[idx], 0, 1) if X.max() <= 1.0001 else X[idx]
    return X, y


def _simulate_key_compromise_impersonation(X, y, rng, frac=0.25):
    X = X.copy()
    normal_mean = X[y == 0].mean(axis=0) if np.any(y == 0) else X.mean(axis=0)
    attack_idx = np.where(y == 1)[0]
    n = max(1, int(frac * len(attack_idx)))
    idx = rng.choice(attack_idx, size=n, replace=False)
    blend = rng.uniform(0.4, 0.8, size=(n, 1))
    X[idx] = blend * normal_mean[None, :] + (1 - blend) * X[idx]
    return X, y


def _simulate_sybil(X, y, rng, n_sources=3, copies=6, noise_scale=0.05):
    attack_idx = np.where(y == 1)[0]
    if len(attack_idx) == 0:
        return X, y
    sources = rng.choice(attack_idx, size=min(n_sources, len(attack_idx)), replace=False)
    fake_rows, fake_labels = [], []
    for s in sources:
        for _ in range(copies):
            fake_rows.append(X[s] + rng.normal(0, noise_scale, size=X.shape[1]))
            fake_labels.append(1)
    X_sybil = np.vstack([X, np.array(fake_rows)])
    y_sybil = np.concatenate([y, np.array(fake_labels)])
    return X_sybil, y_sybil


ATTACK_SIMULATORS = {
    "Replay": _simulate_replay,
    "Man-in-the-Middle": _simulate_mitm,
    "Key-Compromise Impersonation": _simulate_key_compromise_impersonation,
    "Sybil": _simulate_sybil,
}


def run_resistance_analysis(train_pct: int = 90, seed: int = None):
    seed = config.RANDOM_STATE if seed is None else seed
    rng = np.random.default_rng(seed)

    X_train, X_test, y_train, y_test = train_utils.prepare_data(
        train_pct=train_pct, seed=seed)
    dmn, weights, _ = train_utils.train_dmn_with_optimizer(
        X_train, y_train, optimizer_name="HDTBO",
        max_iterations=config.MAX_ITERATIONS, pop_size=config.POP_SIZE, seed=seed)

    accuracies = []
    for attack_name in config.ATTACK_TYPES:
        simulate = ATTACK_SIMULATORS[attack_name]
        X_attacked, y_attacked = simulate(X_test, y_test, rng)
        pred = dmn.predict(X_attacked, weights)
        acc = metrics_mod.accuracy(y_attacked, pred)
        accuracies.append(acc)
        print(f"[resistance_analysis] {attack_name}: accuracy = {acc:.4f}")

    save_path = os.path.join(config.OUTPUT_DIR, "figure13_resistance_analysis.png")
    line_chart(
        x_labels=config.ATTACK_TYPES,
        series={"Proposed HDTBO_DMN": accuracies},
        ylabel="Accuracy", xlabel="Attack type",
        title="Figure 13. Resistance analysis\n(accuracy under simulated attack types)",
        save_path=save_path,
    )
    return dict(zip(config.ATTACK_TYPES, accuracies))


if __name__ == "__main__":
    run_resistance_analysis()
