"""
data_utils.py
=============
Dataset loading, missing-value handling, Min-Max normalization and SMOTE
augmentation, as described in Section 4.2 / 5.2 of the manuscript.

- load_dataset(): loads the real BoT-IoT csv if present at
  config.DATA_CSV_PATH, otherwise generates a synthetic BoT-IoT-like
  dataset with the same extreme class imbalance reported in Table 6 of
  the paper (38 normal : 999,962 attack per 1,000,000 samples), so that
  the rest of the pipeline is always runnable.
- handle_missing_values(): mean-imputation for numeric columns.
- min_max_normalize(): scales every feature into [0, 1].
- smote_augment(): balances classes with SMOTE (imblearn), matching
  "data augmentation using SMOTE to address class imbalance".
"""

import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from imblearn.over_sampling import SMOTE

import config



def load_dataset() -> pd.DataFrame:
    """Load the BoT-IoT csv if present, else fall back to synthetic data."""
    path = config.DATA_CSV_PATH
    df = pd.read_csv(path)
    if config.LABEL_COLUMN not in df.columns:
        raise ValueError(
            f"Expected a '{config.LABEL_COLUMN}' column in {path}. "
            "Rename your target column or update config.LABEL_COLUMN."
        )
    return df




def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """Mean-imputation for missing numeric values ("missing value handling")."""
    df = df.copy()
    feature_cols = [c for c in df.columns if c != config.LABEL_COLUMN]
    df[feature_cols] = df[feature_cols].apply(lambda col: col.fillna(col.mean()))
    return df


def min_max_normalize(df: pd.DataFrame, scaler: MinMaxScaler = None):
    """Min-Max normalization of every feature column into [0, 1]."""
    df = df.copy()
    feature_cols = [c for c in df.columns if c != config.LABEL_COLUMN]
    if scaler is None:
        scaler = MinMaxScaler()
        df[feature_cols] = scaler.fit_transform(df[feature_cols])
    else:
        df[feature_cols] = scaler.transform(df[feature_cols])
    return df, scaler


def smote_augment(X: np.ndarray, y: np.ndarray, random_state: int = None):
    """SMOTE-based data augmentation to correct class imbalance."""
    random_state = config.RANDOM_STATE if random_state is None else random_state
    n_minority = int(min(np.bincount(y.astype(int))))
    k_neighbors = max(1, min(5, n_minority - 1))
    if k_neighbors < 1:
        # too few minority samples for SMOTE, duplicate instead
        return X, y
    sm = SMOTE(random_state=random_state, k_neighbors=k_neighbors)
    X_res, y_res = sm.fit_resample(X, y)
    return X_res, y_res


def preprocess_pipeline(df: pd.DataFrame, apply_augmentation: bool = True,
                         random_state: int = None):
    """
    Full preprocessing pipeline: missing-value handling -> Min-Max
    normalization -> (optional) SMOTE augmentation.
    Returns X (features, np.ndarray), y (labels, np.ndarray).
    """
    df = handle_missing_values(df)
    df, _ = min_max_normalize(df)

    feature_cols = [c for c in df.columns if c != config.LABEL_COLUMN]
    X = df[feature_cols].values.astype(np.float64)
    y = df[config.LABEL_COLUMN].values.astype(int)

    if apply_augmentation:
        X, y = smote_augment(X, y, random_state=random_state)

    return X, y
